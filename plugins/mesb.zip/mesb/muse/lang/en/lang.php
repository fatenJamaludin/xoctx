<?php return [
    'plugin' => [
        'name' => 'muse',
        'description' => ''
    ]
];