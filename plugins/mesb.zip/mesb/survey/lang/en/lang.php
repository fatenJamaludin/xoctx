<?php return [
    'plugin' => [
        'name' => 'Survey',
        'description' => ''
    ]
];